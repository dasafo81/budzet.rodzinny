import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!url || !key) {
  throw new Error('Brak zmiennych środowiskowych VITE_SUPABASE_URL i VITE_SUPABASE_ANON_KEY')
}

export const sb = createClient(url, key)
